Submission: Winston Zhang, wyz5rge
Date: 6. April 2023
Assignment: p2exp2b
Description: Build instructions for submitted code

The only changes made to the code implementation were to the code body. No new libraries were included and no new namespaces were added.
The only changes made to run.sh were that some parameters were commented out in favor of others. Since I technically "modified" it, it is included in my tarball,
    so the instructors can see the parameters I used to test my implementation.
My submitted code should be run as the instructors intended (cmake .; make; ./run.sh)